#!/bin/bash
pip install -r requirements.txt
mkdir -p data/{input,output} logs
chmod +x scripts/*.py

